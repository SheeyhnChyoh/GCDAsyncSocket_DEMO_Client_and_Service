//
//  Service.m
//  ServiceSocket
//
//  Created by Longcai on 16/3/9.
//  Copyright (c) 2016年 Longcai. All rights reserved.
//

#import "Service.h"
#import "GCDAsyncSocket.h"

@interface Service()<GCDAsyncSocketDelegate>
@property (nonatomic,strong) GCDAsyncSocket * serverSocket;
@property (nonatomic,strong) NSMutableArray * clientSockets;
@end

@implementation Service

-(GCDAsyncSocket *)serverSocket{
    if (_serverSocket == nil) {
        _serverSocket = [[GCDAsyncSocket alloc]initWithDelegate:self delegateQueue:dispatch_get_global_queue(0, 0)];
    }
    return _serverSocket;
}

-(NSMutableArray *)clientSockets{
    if (_clientSockets == nil) {
        _clientSockets = [NSMutableArray array];
    }
    return _clientSockets;
}

-(void)startServer{
    NSError * error = nil;
    [self.serverSocket acceptOnPort:1760 error:&error];
}

-(void)socket:(GCDAsyncSocket *)sock didAcceptNewSocket:(GCDAsyncSocket *)newSocket{
    [self.clientSockets addObject:newSocket];
    [newSocket readDataWithTimeout:-1 tag:10002];
}

-(void)socket:(GCDAsyncSocket *)sock didReadData:(NSData *)data withTag:(long)tag{
    for (GCDAsyncSocket * currentSocket in self.clientSockets) {
        if (currentSocket != sock) {
            [currentSocket writeData:data withTimeout:-1 tag:123];
        }
        
    }
    [sock readDataWithTimeout:-1 tag:1231];
}

+(Service *)shareServerInstance{
    static dispatch_once_t onceToken;
    static Service * server;
    dispatch_once(&onceToken, ^{
        server = [[Service alloc]init];
    });
    return server;
}

+(Service *)shareServerInstanceNoSingle{
    return [[Service alloc]init];
}

@end
