//
//  ViewController.m
//  Client
//
//  Created by Longcai on 16/3/9.
//  Copyright (c) 2016年 Longcai. All rights reserved.
//

#import "ViewController.h"
#import "Masonry.h"
#import "GCDAsyncSocket.h"

@interface ViewController ()<GCDAsyncSocketDelegate>
@property (nonatomic,strong) GCDAsyncSocket * clientSocket;
@property (nonatomic,strong) UILabel * label;
@end

@implementation ViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    // Do any additional setup after loading the view, typically from a nib.

    UILabel * label = [[UILabel alloc]initWithFrame:CGRectMake(7, 64, 262, 123)];
    self.label = label;
    label.textColor = [UIColor redColor];
    label.backgroundColor = [UIColor grayColor];
    [self.view addSubview:label];
    NSLog(@"%f",[UIScreen mainScreen].bounds.size.width);
    
    UIEdgeInsets padding = UIEdgeInsetsMake(10, 10, 10, 10);
    
    [label mas_makeConstraints:^(MASConstraintMaker *make) {
        make.edges.equalTo(self.view).with.insets(padding);
    }];
    
    self.clientSocket = [[GCDAsyncSocket alloc]initWithDelegate:self delegateQueue:dispatch_get_global_queue(0, 0)];
    NSError * err = nil;
    [self.clientSocket connectToHost:@"127.0.0.1" onPort:1760 error:&err];
    
    
}

-(void)socket:(GCDAsyncSocket *)sock didConnectToHost:(NSString *)host port:(uint16_t)port{
    [sock readDataWithTimeout:-1 tag:123];
}

-(void)socket:(GCDAsyncSocket *)sock didReadData:(NSData *)data withTag:(long)tag{
    NSString * str = [[NSString alloc]initWithData:data encoding:NSUTF8StringEncoding];
    self.label.text = str;
}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

@end
